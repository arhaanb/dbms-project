<template>
	<main class="container">
		<br /><br />
		<br /><br />
		<br /><br />
		<br /><br />
		<h1 class="zero">Your order was successfully placed!</h1>
		<h5>Thanks for shopping with us!</h5>

		<nuxt-link to="/">
			<button>Home</button>
		</nuxt-link>
	</main>
</template>

<style lang="scss" scoped></style>
